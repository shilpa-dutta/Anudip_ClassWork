package org.anudip.bean;

public class Demo {

}
