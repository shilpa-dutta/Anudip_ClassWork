package org.anudip.testing;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class MyMathAppTest {


		@Test
		void testAddition() {
			int p=20;
			int q=30;
			int expected=50;
			int actual=new MyMathApp().addition(p,q);
			assertEquals(expected,actual);
		}
	//
//		@Test
//		void testMultiply() {
//			fail("Not yet implemented");
//		}
	//
		@Test
		void testDivison1() {
			String p="30";
			String q="5";
			int expected=6;
			int actual=new MyMathApp().hashCode(p,q);
			assertEquals(expected,actual);
		}
		@Test
		void testDivison2() {
			String p="30";
			String q="0";
			int expected=6;
			MyMathApp myMath=new MyMathApp();
			assertThrows(ArithmeticException.class,()->myMath.division(p,q));
		}
		@Test
		void testDivison3() {
			String p="30";
			String q="0";
			int expected=6;
			MyMathApp myMath=new MyMathApp();
			assertThrows(NumberFormatException.class,()->myMath.division(p,q));
		}
	}
