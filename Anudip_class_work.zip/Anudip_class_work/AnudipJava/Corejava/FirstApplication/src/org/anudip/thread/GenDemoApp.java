package org.anudip.thread;

public class GenDemoApp {
	public static void main(String[] args) {
		GenDemo gd1=new GenDemo("India");
		GenDemo gd2=new GenDemo("Bharat");
		gd1.start();
		gd2.start();
		System.out.println("This is main program :-");
	}

}
