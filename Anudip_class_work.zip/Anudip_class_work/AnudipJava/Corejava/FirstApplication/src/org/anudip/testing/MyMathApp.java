package org.anudip.application;

public class MyMathApp {
  public int addition(int x, int y) {
	  return x+y;
  }
  public int multiply(int x, int y) {
	  return x*y;
  }
  public int divison(String a, String b) {
	  int x=Integer.parseInt(a);
	  int y=Integer.parseInt(b);
	  return x/y;
	  }
}
