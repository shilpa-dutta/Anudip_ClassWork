package org.anudip.application;

public class Voter {
public validVoterCheck(int age) {
	if(age>=18)
		return true;
	else
		return false;
}
}
