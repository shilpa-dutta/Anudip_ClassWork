package org.anudip.bean;

public class MyEmployee {

}
