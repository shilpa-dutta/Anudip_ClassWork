package org.anudip.hibernateLab.application;

import org.anudip.hibernateLab.bean.Product;
import org.anudip.hibernateLab.dao.DatabaseHandler;
import org.hibernate.Session;


import java.util.List;

import org.hibernate.query.Query;

public class ProductShow {

	public static void main(String[] args) throws Exception{
		DatabaseHandler dbHandler=DatabaseHandler.getDatabaseHandler();
   	    Session session=dbHandler.createSession();
   	 String queryStatement="from Product";
   	Query<Product> query=session.createQuery(queryStatement);
    List<Product> productList=query.list();
    productList.forEach(product->System.out.println(product));
	   	 session.close();

	}

}