package org.anudip.hibernateLab.bean;
public class EssentialCommodityException extends RuntimeException {
    public EssentialCommodityException(String message) {
        super(message);
    }
}