package org.anudip.hibernateLab2.application;

import java.util.Scanner;


import org.anudip.hibernateLab2.bean.Result;
import org.anudip.hibernateLab2.bean.Student;
import org.anudip.hibernateLab2.dao.DatabaseHandler;
import org.anudip.hibernateLab2.bean.StudentNotFoundException; // Import StudentNotFoundException
import org.anudip.hibernateLab2.bean.ResultService; // Import ResultService
import org.hibernate.Session;
import org.hibernate.Transaction;

public class StudentMain {
    private static final Scanner scanner = new Scanner(System.in);

 // Method to insert a student record into the database
    public static void insertRecord() {
        try {
            Session session = DatabaseHandler.getDatabaseHandler().createSession();
            Transaction transaction = session.beginTransaction();

            System.out.print("Enter Roll Number: ");
            String rollNumber = scanner.next();

            // Check if a student with the same roll number already exists
            Student existingStudent = session.get(Student.class, rollNumber);
            if (existingStudent != null) {
                System.out.println("Student with Roll Number " + rollNumber + " already exists.");
                session.close();
                return;
            }

            System.out.print("Enter Student Name: ");
            String studentName = scanner.next();
            System.out.print("Enter Semester: ");
            String semester = scanner.next();
            System.out.print("Enter Half-Yearly Total: ");
            double halfYearlyTotal = scanner.nextDouble();
           Result result = new Result();
           result.setRollNumber(rollNumber);
           result.setHalfYearlyTotal(halfYearlyTotal);
           

            // Create a Student object with the provided halfYearlyTotal
            Student student = new Student(rollNumber, studentName, semester, result );

            session.save(student);
            transaction.commit();
            session.close();

            System.out.println("Student record added successfully.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

 // Method to update a student's annual exam results and calculate the grade
    public static void updateRecord() {
        try {
            Session session = DatabaseHandler.getDatabaseHandler().createSession();
            Transaction transaction = session.beginTransaction();

            System.out.print("Enter Roll Number: ");
            String rollNumber = scanner.next();

            Student student = session.get(Student.class, rollNumber);

            if (student == null) {
                throw new StudentNotFoundException("Student with Roll Number " + rollNumber + " not found.");
            }

            System.out.print("Enter Annual Exam Marks (English, Language, Mathematics, Science, Social Study separated by commas): ");
            String examMarksInput = scanner.next();
            String[] examMarksArray = examMarksInput.split(",");

            if (examMarksArray.length != 5) {
                System.out.println("Invalid input. Please provide marks for all subjects.");
                session.close();
                return;
            }

            double englishMarks = Double.parseDouble(examMarksArray[0]);
            double languageMarks = Double.parseDouble(examMarksArray[1]);
            double mathMarks = Double.parseDouble(examMarksArray[2]);
            double scienceMarks = Double.parseDouble(examMarksArray[3]);
            double socialMarks = Double.parseDouble(examMarksArray[4]);

            double annualTotal = englishMarks + languageMarks + mathMarks + scienceMarks + socialMarks;
            Result result =student.getStudentResult();
            result.setAnnualTotal(annualTotal);

            // Calculate grade using ResultService class
            String grade = ResultService.gradeCalculation(result);

            result.setGrade(grade);
            session.saveOrUpdate(result);
            transaction.commit();
            session.close();

            System.out.println("Student record updated successfully. Grade: " + grade);
        } catch (StudentNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

 // Method to display a student's details and exam results
    public static void displayRecord() {
        try {
            Session session = DatabaseHandler.getDatabaseHandler().createSession();

            System.out.print("Enter Roll Number: ");
            String rollNumber = scanner.next();

            Student student = session.get(Student.class, rollNumber);

            if (student == null) {
                throw new StudentNotFoundException("Student with Roll Number " + rollNumber + " not found.");
            }

            Result result = session.get(Result.class, rollNumber);
            System.out.println("Student Details:");
            System.out.println("Roll Number: " + student.getRollNumber());
            System.out.println("Student Name: " + student.getStudentName());
            System.out.println("Semester: " + student.getSemester());
            System.out.println("\nResult Details:");
            System.out.println("Half-Yearly Total: " + result.getHalfYearlyTotal());
            System.out.println("Annual Total: " + result.getAnnualTotal());
            System.out.println("Grade: " + result.getGrade());

            session.close();
        } catch (StudentNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Student Entry");
            System.out.println("2. Result Update");
            System.out.println("3. Show Student");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    insertRecord();
                    break;
                case 2:
                    updateRecord();
                    break;
                case 3:
                    displayRecord();
                    break;
                case 4:
                    System.out.println("Exiting the program.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }//end of main
}//end of class
