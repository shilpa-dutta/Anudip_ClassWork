package org.anudip.hibernateLab2.bean;

import javax.persistence.*;
@Entity
@Table(name = "Student")
public class Student {
	
	// Define the primary key for the Student entity, mapping it to the "Roll_Number" column in the database.
    @Id
    @Column(name = "Roll_Number")
    private String rollNumber;
    
 // Define a column named "Student_Name" to store the student's name.
    @Column(name = "Student_Name")
    private String studentName;

 // Define a column named "Semester" to store the student's semester information.
    @Column(name = "Semester")
    private String semester;
    
 // Establish a one-to-one relationship with the Result entity using lazy loading and cascading all operations.
    // Join the "Roll_Number" column in the Student table with the primary key of the Result table.
    @OneToOne(fetch = FetchType.LAZY, targetEntity = Result.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "Roll_Number")
    private Result studentResult;


  

    public Student() {
        super();
    }

 // Parameterized constructor to initialize the Student object with relevant attributes.
    public Student(String rollNumber, String studentName, String semester, Result studentResult) {
        super();
        this.rollNumber = rollNumber;
        this.studentName = studentName;
        this.semester = semester;
        this.studentResult= studentResult;
    }

 // Getter and setter methods for the Student class.
    public String getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public Result getStudentResult() {
        return studentResult;
    }

    public void setStudentResult(Result studentResult) {
        this.studentResult = studentResult;
    }


    @Override
    public String toString() {
        return String.format("%-5s %-20s %-5s %-2s", rollNumber, studentName, semester, studentResult);
    }
}//end of class
