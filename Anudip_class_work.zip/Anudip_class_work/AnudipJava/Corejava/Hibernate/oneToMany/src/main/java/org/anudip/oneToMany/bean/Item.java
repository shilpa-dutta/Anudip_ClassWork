package org.anudip.oneToMany.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Item {
	@Id
	@Column(name="serial_number")
	private Integer serialNumber;
	@Column(name="item_name")
	private String itemName;
	private Double price;
	@Column(name="purchase_quantity")
	private Double purchaseQuantity;
	private Double amount;
	@Column(name="bill_number")
	private Long billNumber;
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Item(Integer serialNumber, String itemName, Double price, Double purchaseQuantity, Double amount,
			Long billNumber) {
		super();
		this.serialNumber = serialNumber;
		this.itemName = itemName;
		this.price = price;
		this.purchaseQuantity = purchaseQuantity;
		this.amount = amount;
		this.billNumber = billNumber;
	}
	public Integer getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(Integer serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getPurchaseQuantity() {
		return purchaseQuantity;
	}
	public void setPurchaseQuantity(Double purchaseQuantity) {
		this.purchaseQuantity = purchaseQuantity;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Long getBillNumber() {
		return billNumber;
	}
	public void setBillNumber(Long billNumber) {
		this.billNumber = billNumber;
	}
	@Override
	public String toString() {
		String output=String.format("%-5s %-15s %-10s %-10s %-10s",serialNumber,itemName,price,purchaseQuantity,amount);
		return output;
	}
	
	
}
