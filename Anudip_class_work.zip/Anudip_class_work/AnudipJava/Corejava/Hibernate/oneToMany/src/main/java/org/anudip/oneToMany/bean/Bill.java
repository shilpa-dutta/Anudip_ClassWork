package org.anudip.oneToMany.bean;



public class Bill {

}
