package org.anudip.mavenApplication.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseHandler {
	private static DatabaseHandler dbHandler = new DatabaseHandler();
	
	private DatabaseHandler() {
		
	}
	public static DatabaseHandler getDatabaseHandler() {
		return dbHandler;
	}
	private Connection connection = null;
public Connection getConnection() throws Exception{
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection connection=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/c5904","root","root");
	return connection;
}
}
