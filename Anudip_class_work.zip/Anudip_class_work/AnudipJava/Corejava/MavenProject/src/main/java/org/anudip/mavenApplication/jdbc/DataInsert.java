package org.anudip.mavenApplication.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
public class DataInsert {
	public static void main(String[] args) throws Exception{
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Department Id:");
		int id=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter Department Name:");
		String name=scanner.nextLine();
		System.out.println("Enter Department Location");
		String location=scanner.nextLine();
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/c5904","root","root");
		String sqlStatement="insert into department values (?,?,?)";
		PreparedStatement statement=connection.prepareStatement(sqlStatement);
		statement.setInt(1, id);
		statement.setString(2, name);
		statement.setString(3, location);
		statement.executeUpdate();
		System.out.println("New Record inserted");
		connection.close();
	}
}