package org.anudip.mavenApplication.collection;

import java.util.LinkedHashMap;
import java.util.Set;


public class LinkedHashMapDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      LinkedHashMap<Integer,String>myMap=new LinkedHashMap<>();
      myMap.put(103,"Rose");
      myMap.put(105,"Tulip");
      myMap.put(101,"Cosmos");
      myMap.put(104,"Rose");
      myMap.put(102,"Marigold");
      myMap.put(106,"Lotus");
     Set<Integer>allKeys=myMap.keySet();
	
	for(Integer ig:allKeys) {
		String str=myMap.get(ig);
	System.out.println(ig+"-"+str);
	}

}
}
