package org.anudip.mavenApplication.collection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ListIterator;
import java.util.PriorityQueue;
public class PriorityQueueDemo1 {

	public static void main(String[] args) {
		PriorityQueue <String>myQueue = new PriorityQueue<String>();
		myQueue.add("Mango");
		myQueue.add("Apple");
		myQueue.add("Guava");
		myQueue.add("Pinapple");
		myQueue.add("Lichi");
		myQueue.add("Plum");
		myQueue.forEach(str->System.out.println(str));
	}

}
