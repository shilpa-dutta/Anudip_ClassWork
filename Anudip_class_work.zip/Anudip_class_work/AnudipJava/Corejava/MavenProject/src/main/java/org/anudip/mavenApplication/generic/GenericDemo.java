package org.anudip.mavenApplication.generic;

public class GenericDemo<T> {
	 public void swapData(T x,T y) {
   System.out.println("Before Swaping value of x:"+x+" value of y:"+y);
   T z=x;
   x=y;
   y=z;
   System.out.println("After Swaping value of x:"+x+" value of y:"+y);
   }
	 //HERE T REPRESENT any data type.
	 
//   public void swapData(Double x,Double y) {
//	   System.out.println("Before Swaping value of x:"+x+" value of y:"+y);
//	   Double z=x;
//	   x=y;
//	   y=z;
//	   System.out.println("After Swaping value of x:"+x+" value of y:"+y);
//	   }
//   public void swapData(String x, String y) {
//	   System.out.println("Before Swaping value of x:"+x+" value of y:"+y);
//	   String z=x;
//	   x=y;
//	   y=z;
//	   System.out.println("After Swaping value of x:"+x+" value of y:"+y);
//	   }
}
