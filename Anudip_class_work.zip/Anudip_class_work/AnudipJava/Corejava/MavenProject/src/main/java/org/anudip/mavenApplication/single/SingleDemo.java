package org.anudip.mavenApplication.single;

public class SingleDemo {
	private int i;
	private static SingleDemo sd = new SingleDemo();
	
	public static SingleDemo getSingleDemo() {
		return sd;
	}
	private SingleDemo() {
		i = 10;
	}
	public void putdata(int x) {
		i=x;
	}
	public int getdata() {
		return i;
	}
}