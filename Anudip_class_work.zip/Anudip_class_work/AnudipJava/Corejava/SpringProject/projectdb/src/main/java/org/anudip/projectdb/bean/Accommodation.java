package org.anudip.projectdb.bean;

@Entity
public class Accommodation {
	@Id
	 private String id;
    private String name;
    private double farePerDay;
	public Accommodation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Accommodation(String id, String name, double farePerDay) {
		super();
		this.id = id;
		this.name = name;
		this.farePerDay = farePerDay;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getFarePerDay() {
		return farePerDay;
	}
	public void setFarePerDay(double farePerDay) {
		this.farePerDay = farePerDay;
	}
	@Override
	public String toString() {
		return "id=" + id + ", name=" + name + ", farePerDay=" + farePerDay + " ";
	}
    

}