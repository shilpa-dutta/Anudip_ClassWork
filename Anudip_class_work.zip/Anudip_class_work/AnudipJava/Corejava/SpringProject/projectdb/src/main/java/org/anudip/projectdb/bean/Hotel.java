package org.anudip.projectdb.bean;

public class Hotel {

}
