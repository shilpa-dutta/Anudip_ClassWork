package org.anudip.autowireApp.application;

import org.anudip.autowireApp.bean.Employee;
import org.anudip.autowireApp.config.EmployeeConfig1;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
public class EmployeeMain1 {

	public static void main(String[] args) throws Exception {
		ApplicationContext appContext=new AnnotationConfigApplicationContext(EmployeeConfig1.class);
		Employee emp=appContext.getBean(Employee.class);
		System.out.println(emp);

	}

}
