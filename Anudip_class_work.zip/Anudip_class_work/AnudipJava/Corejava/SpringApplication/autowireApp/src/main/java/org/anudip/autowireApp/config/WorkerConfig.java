package org.anudip.autowireApp.config;
import org.anudip.autowireApp.bean.Address;
import org.anudip.autowireApp.bean.Worker;
import org.springframework.context.annotation.Bean;
public class WorkerConfig {

		@Bean(name="current")
		public Address address1() {
			Address add=new Address();
			add.setStreet("23,Bandra West");
			add.setCity("Mumbai");
			add.setPin(40005);
			return add;
		}
		@Bean(name="parmanent")
		public Address address2() {
			Address add=new Address();
			add.setStreet("16,Rathtola");
			add.setCity("Puri");
			add.setPin(30004);
			return add;
		}
			
		@Bean
		public 	Worker 	worker () {
			Worker  wk=new Worker();
		wk.setEmployeeId(10009);
		wk.setEmployeeName("JAGANNATH MAHARAJ");
		wk.setEmployeeSalary(560000.00);
		return wk;
		}
	}