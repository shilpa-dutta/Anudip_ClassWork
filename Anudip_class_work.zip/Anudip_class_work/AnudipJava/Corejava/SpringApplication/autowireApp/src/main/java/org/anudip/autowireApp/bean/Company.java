package org.anudip.autowireApp.bean;
//autowired by Type
import org.springframework.beans.factory.annotation.Autowired;

public class Company {
private Integer companyId;
private String companyName;
private Address companyAddress;
public Company() {
	super();
	// TODO Auto-generated constructor stub
}
public Company(Integer companyId, String companyName, Address companyAdd) {
	super();
	this.companyId = companyId;
	this.companyName = companyName;
	this.companyAddress = companyAddress;
}
public Integer getCompanyId() {
	return companyId;
}
public void setCompanyId(Integer companyId) {
	this.companyId = companyId;
}
public String getCompanyName() {
	return companyName;
}
public void setCompanyName(String companyName) {
	this.companyName = companyName;
}
public Address getCompanyAddress() {
	return companyAddress;
}
@Autowired
public void setCompanyAdd(Address companyAddress) {
	this.companyAddress = companyAddress;
}
@Override
public String toString() {
	return "companyId=" + companyId + ", companyName=" + companyName + ", companyAddress=" + companyAddress;
	
}


}
