package org.anudip.autowireApp.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

//autowiring by Name
public class Worker {
	private Integer employeeId;
	private String employeeName;
	private Address currentAddress;
	private Address parmanentAddress;
	private double employeeSalary;
	public Worker() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Worker(Integer employeeId, String employeeName, Address currentAddress, Address parmanentAddress,
			double employeeSalary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.currentAddress = currentAddress;
		this.parmanentAddress = parmanentAddress;
		this.employeeSalary = employeeSalary;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Address getCurrentAddress() {
		return currentAddress;
	}
	@Autowired
	@Qualifier("current")
	public void setCurrentAddress(Address currentAddress) {
		this.currentAddress = currentAddress;
	}
	public Address getParmanentAddress() {
		return parmanentAddress;
	}
	@Autowired
	@Qualifier("parmanent")
	public void setParmanentAddress(Address parmanentAddress) {
		this.parmanentAddress = parmanentAddress;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	@Override
	public String toString() {
		return "employeeId=" + employeeId + ", employeeName=" + employeeName + ", currentAddress="
				+ currentAddress + ", parmanentAddress=" + parmanentAddress + ", employeeSalary=" + employeeSalary;
	}

}