package org.anudip.autowireApp.config;

import org.anudip.autowireApp.bean.Address;
import org.anudip.autowireApp.bean.Employee;
import org.springframework.context.annotation.Bean;


public class EmployeeConfig1 {

	@Bean
	public Address address() {
		return new Address("78,Aminbad Road","Hyderabad",500020);
	}
	@Bean
	public Employee employee() {
		return new Employee(10003,"Shilpa Dutta",75000.00);
	}
}