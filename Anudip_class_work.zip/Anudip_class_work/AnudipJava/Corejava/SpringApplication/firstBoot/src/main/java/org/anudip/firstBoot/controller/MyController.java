package org.anudip.firstBoot.controller;

import org.anudip.firstBoot.service.PrimeService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
public class MyController{
	PrimeService pservice;
	@GetMapping("/index")
	public ModelAndView showIndexPage() {
		ModelAndView mv=new ModelAndView("indexPage");
		return mv;
	}
	@GetMapping("/home")
	public ModelAndView showHomePage() {
		return new ModelAndView ("homePage");
	}
	@GetMapping("/abc")
	public ModelAndView showNextPage() {
		return new ModelAndView("nextPage");
	}
	@GetMapping("/accept")
	public ModelAndView showAcceptPage() {
		return new ModelAndView("acceptPage");
	}
}
