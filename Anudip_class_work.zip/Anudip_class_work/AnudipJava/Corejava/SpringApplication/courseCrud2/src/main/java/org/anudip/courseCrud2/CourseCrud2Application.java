package org.anudip.courseCrud2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseCrud2Application {

	public static void main(String[] args) {
		SpringApplication.run(CourseCrud2Application.class, args);
	}

}
