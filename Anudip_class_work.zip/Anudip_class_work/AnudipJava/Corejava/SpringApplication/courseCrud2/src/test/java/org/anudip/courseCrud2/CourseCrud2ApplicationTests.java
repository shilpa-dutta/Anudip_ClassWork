package org.anudip.courseCrud2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseCrud2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
