package org.anudip.courseCrud.dao;

import org.anudip.courseCrud.bean.Course;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course, Long> {

}
