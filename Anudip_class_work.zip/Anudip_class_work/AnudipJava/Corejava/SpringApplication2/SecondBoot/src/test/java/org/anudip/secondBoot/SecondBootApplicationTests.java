package org.anudip.secondBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
