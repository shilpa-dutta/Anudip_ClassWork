package org.anudip.labBoot.service;

import org.springframework.stereotype.Service;

@Service
public class CalculatorService {
    public int performCalculation(String operand1, String operand2, String operator) {
        // Implement your calculation logic here
        int result = 0;
        if ("+".equals(operator)) {
            result = Integer.parseInt(operand1) + Integer.parseInt(operand2);
        } else if ("-".equals(operator)) {
            result = Integer.parseInt(operand1) - Integer.parseInt(operand2);
        } else if ("*".equals(operator)) {
            result = Integer.parseInt(operand1) * Integer.parseInt(operand2);
        } else if ("/".equals(operator)) {
            result = Integer.parseInt(operand1) / Integer.parseInt(operand2);
        }
        return result;
    }
}