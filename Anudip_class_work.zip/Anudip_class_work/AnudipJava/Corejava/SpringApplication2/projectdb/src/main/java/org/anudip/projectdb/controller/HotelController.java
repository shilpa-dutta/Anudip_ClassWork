package org.anudip.projectdb.controller;

import org.anudip.projectdb.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hotel")
public class HotelController {
	 @Autowired
	    private HotelService service;

}