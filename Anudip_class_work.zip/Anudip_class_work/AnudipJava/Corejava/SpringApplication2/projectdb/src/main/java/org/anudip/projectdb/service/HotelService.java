package org.anudip.projectdb.service;

import org.anudip.projectdb.dao.HotelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class HotelService {
	 @Autowired
	    private HotelRepository repository;

}