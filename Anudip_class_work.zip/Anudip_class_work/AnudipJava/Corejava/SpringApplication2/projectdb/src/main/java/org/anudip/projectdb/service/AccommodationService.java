package org.anudip.projectdb.service;

import org.anudip.projectdb.dao.AccommodationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccommodationService {
	@Autowired
    private AccommodationRepository repository;

}