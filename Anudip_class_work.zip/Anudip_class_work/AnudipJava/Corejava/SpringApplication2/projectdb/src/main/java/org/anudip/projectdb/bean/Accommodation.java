package org.anudip.projectdb.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Accommodation {
	@Id
	 private String AccomodationId;
    private String AccomodationName;
    private double farePerDay;
	public Accommodation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Accommodation(String accomodationId, String accomodationName, double farePerDay) {
		super();
		AccomodationId = accomodationId;
		AccomodationName = accomodationName;
		this.farePerDay = farePerDay;
	}
	public String getAccomodationId() {
		return AccomodationId;
	}
	public void setAccomodationId(String accomodationId) {
		AccomodationId = accomodationId;
	}
	public String getAccomodationName() {
		return AccomodationName;
	}
	public void setAccomodationName(String accomodationName) {
		AccomodationName = accomodationName;
	}
	public double getFarePerDay() {
		return farePerDay;
	}
	public void setFarePerDay(double farePerDay) {
		this.farePerDay = farePerDay;
	}
	@Override
	public String toString() {
		return "AccomodationId=" + AccomodationId + ", AccomodationName=" + AccomodationName
				+ ", farePerDay=" + farePerDay + " ";
	}
	
		}