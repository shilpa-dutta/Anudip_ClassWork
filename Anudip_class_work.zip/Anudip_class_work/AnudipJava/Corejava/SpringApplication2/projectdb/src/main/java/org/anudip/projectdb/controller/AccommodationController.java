package org.anudip.projectdb.controller;

import org.anudip.projectdb.service.AccommodationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/accommodation")
public class AccommodationController {
	@Autowired
	private AccommodationService service;

}