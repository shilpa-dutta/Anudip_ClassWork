package org.anudip.projectdb.bean;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Client {
	@Id
	private Long ClientId;
	 private String ClientName;
	 private String ClientAddress;
	 private String ClientContactNo;
	 private LocalDate checkInDate;
	 private LocalDate checkOutDate;
	 @ManyToOne
	    private Hotel hotel;
	    @ManyToOne
	    private Accommodation accommodation;
	    private String payStatus;
		public Client() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Client(Long clientId, String clientName, String clientAddress, String clientContactNo,
				LocalDate checkInDate, LocalDate checkOutDate, Hotel hotel, Accommodation accommodation,
				String payStatus) {
			super();
			ClientId = clientId;
			ClientName = clientName;
			ClientAddress = clientAddress;
			ClientContactNo = clientContactNo;
			this.checkInDate = checkInDate;
			this.checkOutDate = checkOutDate;
			this.hotel = hotel;
			this.accommodation = accommodation;
			this.payStatus = payStatus;
		}
		public Long getClientId() {
			return ClientId;
		}
		public void setClientId(Long clientId) {
			ClientId = clientId;
		}
		public String getClientName() {
			return ClientName;
		}
		public void setClientName(String clientName) {
			ClientName = clientName;
		}
		public String getClientAddress() {
			return ClientAddress;
		}
		public void setClientAddress(String clientAddress) {
			ClientAddress = clientAddress;
		}
		public String getClientContactNo() {
			return ClientContactNo;
		}
		public void setClientContactNo(String clientContactNo) {
			ClientContactNo = clientContactNo;
		}
		public LocalDate getCheckInDate() {
			return checkInDate;
		}
		public void setCheckInDate(LocalDate checkInDate) {
			this.checkInDate = checkInDate;
		}
		public LocalDate getCheckOutDate() {
			return checkOutDate;
		}
		public void setCheckOutDate(LocalDate checkOutDate) {
			this.checkOutDate = checkOutDate;
		}
		public Hotel getHotel() {
			return hotel;
		}
		public void setHotel(Hotel hotel) {
			this.hotel = hotel;
		}
		public Accommodation getAccommodation() {
			return accommodation;
		}
		public void setAccommodation(Accommodation accommodation) {
			this.accommodation = accommodation;
		}
		public String getPayStatus() {
			return payStatus;
		}
		public void setPayStatus(String payStatus) {
			this.payStatus = payStatus;
		}
		@Override
		public String toString() {
			return "ClientId=" + ClientId + ", ClientName=" + ClientName + ", ClientAddress=" + ClientAddress
					+ ", ClientContactNo=" + ClientContactNo + ", checkInDate=" + checkInDate + ", checkOutDate="
					+ checkOutDate + ", hotel=" + hotel + ", accommodation=" + accommodation + ", payStatus="
					+ payStatus + " ";
		}
	    
	 

}