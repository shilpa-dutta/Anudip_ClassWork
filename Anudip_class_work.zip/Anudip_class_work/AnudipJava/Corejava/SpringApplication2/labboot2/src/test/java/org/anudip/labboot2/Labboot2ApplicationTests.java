package org.anudip.labboot2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Labboot2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
