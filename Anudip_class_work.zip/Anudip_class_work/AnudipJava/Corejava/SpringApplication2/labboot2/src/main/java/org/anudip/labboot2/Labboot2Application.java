package org.anudip.labboot2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Labboot2Application {

	public static void main(String[] args) {
		SpringApplication.run(Labboot2Application.class, args);
	}

}
