package org.anudip.thread;

public class MyDemoApp {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			MyDemo md1=new MyDemo("India");
			MyDemo md2=new MyDemo("Bharat");
			md1.show();
			md2.show();
			System.out.println("This is main program");

		}

	}
