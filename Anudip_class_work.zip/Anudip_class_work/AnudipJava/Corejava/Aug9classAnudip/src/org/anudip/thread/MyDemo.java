package org.anudip.thread;

public class MyDemo {
	
		private String myName;
		public MyDemo(String myName) {
			super();
			this.myName = myName;
		}
		public void show()  {
			for(int i=0;i<5;i++)  {
				System.out.println("Hello , I am "+myName);
			}

}
}
